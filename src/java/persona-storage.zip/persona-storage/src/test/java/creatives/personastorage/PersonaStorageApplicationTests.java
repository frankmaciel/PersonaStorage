package creatives.personastorage;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PersonaStorageApplicationTests {

	@Test
	void contextLoads() {
	}

}
