package creatives.personastorage;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PersonaStorageApplication {

	public static void main(String[] args) {
		SpringApplication.run(PersonaStorageApplication.class, args);
	}

}
